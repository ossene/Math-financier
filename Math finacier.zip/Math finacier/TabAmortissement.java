/*
***********NAMBININJARA LAZA OSSENE**************
* *********osseneab@gmail.com******************
* ********+261326292170/+261347999053*********

 */


package tabAMOR;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class TabAmortissement extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private int[] p;
	private double[] t, c, m, an;
	Object[][] tb;
	private int periode;
	private double capital;
	private double am;
	private float tx;	  
	  
	public void initialiser() {
	    int n = periode*12;
	    t = new double[n];
	    c = new double[n];
	    m = new double[n];
	    an = new double[n];
	    p = new int[n];
	    tb = new Object[n][5];
	}
	  
	public void remplir() {
	    am = capital/(periode*12);
	    for(int i=0; i<p.length; i++) {
	        p[i] = i+1;
	        c[i] = Math.round(capital);
	        m[i] = Math.round(am);
	        t[i] = Math.round((c[i]*tx)/1200);
	        an[i] = m[i] + t[i];
	        capital -= am; 
	    }
	    for(int i=0; i<p.length; i++) {
	    	tb[i][0] = p[i];
	    	tb[i][1] = c[i];
	    	tb[i][2] = t[i];
	    	tb[i][3] = m[i];
	    	tb[i][4] = an[i];
	    }
	}

	public TabAmortissement(double cpt, float taux, int prd) {
		this.periode = prd;
		this.capital = cpt;
		this.tx = taux;
		
		initialiser();
		remplir();
		
		
		String[] text = {"PERIODE", "K RESTANT DU", "INTERET", "AMORTISSEMENT", "ANNUITE"};
		JTable tab = new JTable(this.tb, text);
		tab.setFont(new Font("Trebuchet MS", Font.BOLD, 22));
		tab.setBackground(new Color(0, 128, 128));
		this.getContentPane().add(new JScrollPane(tab));
		
	}
}	


