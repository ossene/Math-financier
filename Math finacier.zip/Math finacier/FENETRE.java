/* ***********NAMBININJARA LAZA OSSENE************
**************osseneab@gmail.com*************
* ************+261326292170/+261347999053******
 */
package tabAMOR;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Label;
import java.awt.TextField;
import javax.swing.JTextField;
import javax.swing.DropMode;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.JMenuBar;
import com.jgoodies.forms.factories.DefaultComponentFactory;

import tabAmt.TabAmortissement;

import javax.swing.JDesktopPane;
import javax.swing.JTabbedPane;
import java.awt.Toolkit;
import java.awt.Window.Type;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import java.awt.BorderLayout;
import java.awt.Button;
import javax.swing.SwingConstants;

public class FENETRE {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FENETRE window = new FENETRE();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FENETRE() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\OSSENE\\Desktop\\20210126_075323.png"));
		frame.getContentPane().setLayout(null);
		frame.setLocation(5, 50);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 900, 900);
		
		
		JLabel lblNewLabel = new JLabel("TABLEAU D'AMORTISSEMENT");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblNewLabel.setBounds(118, 11, 553, 43);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel CapitalText = new JLabel("CAPITAL");
		CapitalText.setFont(new Font("Arial Black", Font.BOLD, 30));
		CapitalText.setBounds(55, 127, 180, 43);
		frame.getContentPane().add(CapitalText);
		
		JLabel TauxText = new JLabel("TAUX");
		TauxText.setFont(new Font("Arial Black", Font.BOLD, 30));
		TauxText.setBounds(50, 198, 185, 43);
		frame.getContentPane().add(TauxText);
		
		JLabel PeriodeText = new JLabel("PERIODE");
		PeriodeText.setFont(new Font("Arial Black", Font.BOLD, 30));
		PeriodeText.setBounds(51, 280, 213, 43);
		frame.getContentPane().add(PeriodeText);
		
		TextField textField = new TextField();
		textField.setFont(new Font("Dialog", Font.BOLD, 30));
		textField.setBounds(332, 127, 255, 43);
		frame.getContentPane().add(textField);
		textField.setColumns(15);
		
		TextField textField_1 = new TextField();
		textField_1.setFont(new Font("Dialog", Font.BOLD, 30));
		textField_1.setBounds(332, 198, 255, 43);
		frame.getContentPane().add(textField_1);
		textField.setColumns(15);
		
		TextField textField_2 = new TextField();
		textField_2.setFont(new Font("Dialog", Font.BOLD, 30));
		textField_2.setBounds(332, 280, 255, 43);
		frame.getContentPane().add(textField_2);
		textField.setColumns(15);
		
		JLabel lblAriary = new JLabel("Ariary");
		lblAriary.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblAriary.setBounds(593, 127, 180, 43);
		frame.getContentPane().add(lblAriary);
		
		JLabel lblCapital_1 = new JLabel("%");
		lblCapital_1.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblCapital_1.setBounds(593, 198, 180, 43);
		frame.getContentPane().add(lblCapital_1);
		
		JLabel lblAns = new JLabel("Ans");
		lblAns.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblAns.setBounds(593, 280, 180, 43);
		frame.getContentPane().add(lblAns);
		
		

	JButton generer = new JButton("EXECUTER");
	generer.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			String a = textField.getText();
			String b = textField_1.getText();
			String c = textField_2.getText();
			
			double entreCapital = Double.parseDouble(a);
			float entreTaux = Float.parseFloat(b);
			int entrePeriode = Integer.parseInt(c);
			

            TabAmortissement t = new TabAmortissement (entreCapital, entreTaux, entrePeriode);//appell autre fenetre
			t.setVisible(true);
			t.setBounds(100, 100, 900, 900);
		}
	});
	generer.setForeground(new Color(0, 0, 0));
	generer.setBackground(new Color(51, 153, 51));
	generer.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
	generer.setBounds(362, 370, 195, 60);
	frame.getContentPane().add(generer);
}
}
